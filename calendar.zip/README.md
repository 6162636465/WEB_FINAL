# Grupal-Taller Web 2023
Presentacion del proyecto final del taller web

## POR:
### -Javier Oswaldo Alvarez Reyes
### -Paúl Pharaf Supo Portugal 
### -Fabricio
### -Lesel

![ALÓ PROFETA](https://github.com/6162636465/WEB_FINAL/assets/40539959/5779280b-5cca-4a85-90ed-3711b55cb7e4)
